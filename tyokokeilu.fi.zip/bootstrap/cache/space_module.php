<?php return array (
  'providers' => 
  array (
    0 => 'Plugins\\Space\\Providers\\SpaceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Plugins\\Space\\Providers\\SpaceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);