<?php return array (
  'providers' => 
  array (
    0 => 'Plugins\\Job\\Providers\\HotelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Plugins\\Job\\Providers\\HotelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);