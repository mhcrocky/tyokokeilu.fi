<?php
namespace Plugins;
class ModuleServiceProvider extends \Modules\ModuleServiceProvider
{
    public static function getPluginInfo(){
        return [];
    }
}