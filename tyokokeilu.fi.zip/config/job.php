<?php

return [

    'job_route_prefix' => env("JOB_ROUTER_PREFIX","job"),

];