<?php
return [
    'accommodation_route_prefix' => env("ACCOMMODATION_ROUTER_PREFIX","accommodation"),
];