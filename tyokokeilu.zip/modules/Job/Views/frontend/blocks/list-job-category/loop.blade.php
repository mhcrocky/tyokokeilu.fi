<div class="category-list" style="text-align: center">
    <img src="/uploads/demo/event/gallery-2.jpg" alt="" srcset="" class="category-image">
    <span class="category-name">{{ $row->name }}</span>
</div>
<style>
    .category-image{
        height: 150px;
        width: 100%;
        border-radius: 30px;
        margin: auto;
    }
</style>