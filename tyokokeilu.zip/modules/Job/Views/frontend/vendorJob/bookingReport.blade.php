@extends('layouts.user')

@section('head')


Job
@endsection

@section('content')

    @include('Job::frontend.vendorJob.bookingReport.index')

@endsection

@section('footer')



@endsection