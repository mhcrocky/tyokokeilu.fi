<?php
return [
    'page_route_prefix'=>'page'
];