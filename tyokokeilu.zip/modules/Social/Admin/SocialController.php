<?php

namespace Modules\Social\Admin;

use Illuminate\Http\Request;
use Modules\AdminController;
use Modules\Social\Models\Forum;
use Modules\Social\Models\Socialforum;
use Modules\Social\Models\SocialforumTranslation;

class SocialController extends AdminController{

}
