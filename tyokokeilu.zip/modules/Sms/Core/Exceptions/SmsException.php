<?php

namespace Modules\Sms\Core\Exceptions;

use Exception;

class SmsException extends Exception
{

}