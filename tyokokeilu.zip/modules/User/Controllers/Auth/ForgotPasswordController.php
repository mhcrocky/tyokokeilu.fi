<?php


	namespace Modules\User\Controllers\Auth;


	class ForgotPasswordController extends \App\Http\Controllers\Auth\ForgotPasswordController
	{

	}