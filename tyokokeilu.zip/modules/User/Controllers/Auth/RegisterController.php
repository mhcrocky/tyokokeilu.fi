<?php


	namespace Modules\User\Controllers\Auth;


	class RegisterController extends \App\Http\Controllers\Auth\RegisterController
	{

	}