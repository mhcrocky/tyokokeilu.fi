<?php


	namespace Modules\User\Controllers\Auth;


	class ResetPasswordController extends \App\Http\Controllers\Auth\ResetPasswordController
	{

	}