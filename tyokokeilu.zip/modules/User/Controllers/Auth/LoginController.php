<?php


	namespace Modules\User\Controllers\Auth;


	class LoginController extends \App\Http\Controllers\Auth\LoginController
	{

	}