<?php
use Illuminate\Support\Facades\Route;
if(is_enable_language_route())
    include 'web.php';
