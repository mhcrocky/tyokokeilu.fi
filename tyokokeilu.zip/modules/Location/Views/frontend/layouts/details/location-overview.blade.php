@if($translation->content)
    <div class="g-overview">
        <div class="description">
            <?php echo $translation->content ?>
        </div>
    </div>
@endif
