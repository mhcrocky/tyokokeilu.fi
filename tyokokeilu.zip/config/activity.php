<?php
return [
    'activity_route_prefix' => env("ACTIVITY_ROUTER_PREFIX","activity"),
];