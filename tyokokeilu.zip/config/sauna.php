<?php
return [
    'sauna_route_prefix' => env("SAUNA_ROUTER_PREFIX","sauna"),
];